function getDataFromServer(url, printStudents) {
	fetch(url)
	.then (response => {
		if (response.ok) {
			return response.json();
		} else {
			throw "getDataFromServer failed: " + errortext;
		}
	})
	.then(studentList => printStudents(studentList))
}