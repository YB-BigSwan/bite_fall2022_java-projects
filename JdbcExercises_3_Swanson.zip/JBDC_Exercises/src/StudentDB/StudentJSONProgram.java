package StudentDB;

import data_access.StudentDAO;

public class StudentJSONProgram {

	public static void main(String[] args) {
		System.out.println("=== Print students (DAO version) ===");

		StudentDAO studentDAO = new StudentDAO();

		String studentList = studentDAO.getAllStudentsJSON();
		

		if (studentList == null) {
			System.out.println("The database is temporarily unavailable. Please try again later.");
		} else {
			System.out.println(studentList);
		}

	}

}
