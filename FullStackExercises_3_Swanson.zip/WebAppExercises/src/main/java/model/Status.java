package model;

public class Status {
	private int errorCode;
	
	public Status(int errorCode) {
		this.errorCode = errorCode;
	}
	
	public int getErrorCode() {
		return errorCode;
	}

}
