function deleteStudent() {
	let requestURL = "http://localhost:8080/WebAppExercises/deleteStudent";
	let form = document.forms["formStudent"];
	let requestParameters = "id=" + form["id"].value;
	let postOption = {
		method: "POST",
		headers: {
			"Content-Type":"application/x-www-form-urlencoded"},
			body: requestParameters
	};
	fetch(requestURL, postOption)
	.then(response => {
		if (response.ok) {
			return response.json();
		} else {
			throw "getDataFromServer failed: " + response.status;
		}
	})
	.then (status => getErrorCode(status))
}

function getErrorCode(status) {
	if (status.errorCode == 1) {
		alert("Student deleted!")
	} else if (status.errorCode == 0) {
		alert("Student ID not found! Nothing deleted.")
	} else {
		alert("The database is temporarily unavailable. Please try again later")
	}
	
}