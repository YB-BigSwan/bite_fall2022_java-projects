package StudentDB;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

import data_access.ConnectionParameters;
import data_access.DbUtils;

public class SimpleStudentDeleteProgram {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		boolean bool = false;
		int studentID = 0;

		while (bool != true) {
			try {
				System.out.print("Enter ID number of student to be deleted: ");
				studentID = Integer.parseInt(input.nextLine());
				bool = true;
			} catch (NumberFormatException nfe) {
				System.out.println("The value input is not a number! Please enter another ID number.");
			}
		}

		try {
			connection = DriverManager.getConnection(ConnectionParameters.connectionString,
					ConnectionParameters.username, ConnectionParameters.password);

			String sqlText = "DELETE FROM Student WHERE id = ?";

			preparedStatement = connection.prepareStatement(sqlText);

			preparedStatement.setInt(1, studentID);

			int checkExecution = preparedStatement.executeUpdate();

			if (checkExecution == 1) {
				System.out.println("Student deleted!");
			} else if (checkExecution == 0) {
				System.out.println("Nothing deleted. Unknown student ID (" + studentID + ")");
			} else {
				throw new SQLException();
			}

		} catch (SQLException sqle) {
			System.out.println("\n[ERROR] Database error. " + sqle.getMessage());

		} finally {
			DbUtils.closeQuietly(preparedStatement, connection);
			input.close();
		}

	}

}
