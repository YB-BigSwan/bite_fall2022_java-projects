package StudentDB;

import java.util.Scanner;

import data_access.StudentDAO;
import model.Student;

public class StudentUpdateProgram {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		StudentDAO studentDAO = new StudentDAO();

		int studentID = 0;
		boolean bool = false;

		while (bool != true) {
			try {
				System.out.println("=== Update student ===");
				System.out.print("ID: ");
				studentID = Integer.parseInt(input.nextLine());
				bool = true;
			} catch (NumberFormatException nfe) {
				System.out.println("The value input is not a number! Please enter another ID number.");
			}
		}

		System.out.print("First name: ");
		String firstName = input.nextLine();
		
		System.out.print("Last name: ");
		String lastName = input.nextLine();

		System.out.print("Street address: ");
		String streetAddress = input.nextLine();

		System.out.print("Postcode: ");
		String postcode = input.nextLine();

		System.out.print("Post office: ");
		String postOffice = input.nextLine();
		
		Student student = new Student(studentID, firstName, lastName, streetAddress, postcode, postOffice);
		studentDAO.updateStudent(student);
		
		
		input.close();

	}

}
