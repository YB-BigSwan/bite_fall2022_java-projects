package StudentDB;

import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Scanner;
import java.sql.Connection;
import java.sql.PreparedStatement;

import data_access.ConnectionParameters;
import data_access.DbUtils;

public class SimpleStudentInsertProgram {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		Connection connection = null;
		PreparedStatement preparedStatement = null;
	
		boolean bool = false;
		int studentID = 0;
		System.out.println("=== Add student ===");
		//have user enter student number and ensure input is a valid number
		while (bool != true) {
			try {
				System.out.print("Enter ID number of new student: ");
				studentID = Integer.parseInt(input.nextLine());
				bool = true;
			} catch (NumberFormatException nfe) {
				System.out.println("The value input is not a number! Please enter another ID number.");
			}
		}
		//get student's first name
		System.out.print("Enter student's first name: ");
		String firstName = input.nextLine();
		
		//get student's last name
		System.out.print("Enter student's last name: ");
		String lastName = input.nextLine();
		
		//get student's street address
		System.out.print("Enter Student's street address: ");
		String streetAddress = input.nextLine();
		
		//get postacode
		System.out.print("Enter student's postcode: ");
		String postcode = input.nextLine();
		
		//get post office
		System.out.print("Enter post office location: ");
		String postOffice = input.nextLine();
		
		
		
		
		try {
			connection = DriverManager.getConnection(ConnectionParameters.connectionString,
					ConnectionParameters.username, ConnectionParameters.password);
							
			String sqlText = "INSERT INTO Student (id, firstname, lastname, streetaddress, postcode, postoffice) VALUES (?, ?, ?, ?, ?, ?)";
			
			preparedStatement = connection.prepareStatement(sqlText);
			preparedStatement.setInt(1, studentID);
			preparedStatement.setString(2, firstName);
			preparedStatement.setString(3, lastName);
			preparedStatement.setString(4, streetAddress);
			preparedStatement.setString(5, postcode);
			preparedStatement.setString(6, postOffice);
			
			preparedStatement.executeUpdate();

			System.out.println("Student added!");
			
		} catch (SQLException sqle) {
			// First, check if the problem is primary key violation (the error code is vendor-dependent)
			if (sqle.getErrorCode() == ConnectionParameters.PK_VIOLATION_ERROR) {
				System.out.println("Cannot add the Student. " + "The student ID (" + studentID + ") is already in use.");
			} else {
				System.out.println("\n[ERROR] Database error. " + sqle.getMessage());
			}
			
		} finally {
			DbUtils.closeQuietly(preparedStatement, connection);
			input.close();
		}

	}

}
