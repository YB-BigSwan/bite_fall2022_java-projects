package StudentDB;


import java.util.Scanner;

import data_access.StudentDAO;
import model.Student;

public class StudentInsertProgram {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		StudentDAO studentDAO = new StudentDAO();

		int studentID = 0;
		boolean bool = false;

		while (bool != true) {
			try {
				System.out.println("=== Add new student ===");
				System.out.print("Enter an ID number for the new student: ");
				studentID = Integer.parseInt(input.nextLine());
				bool = true;
			} catch (NumberFormatException nfe) {
				System.out.println("The value input is not a number! Please enter another ID number.");
			}
		}

		System.out.print("Enter student's first name: ");
		String firstName = input.nextLine();

		System.out.print("Enter student's last name: ");
		String lastName = input.nextLine();

		System.out.print("Enter Student's street address: ");
		String streetAddress = input.nextLine();

		System.out.print("Enter student's postcode: ");
		String postcode = input.nextLine();

		System.out.print("Enter post office location: ");
		String postOffice = input.nextLine();
		
		Student newStudent = new Student(studentID, firstName, lastName, streetAddress, postcode, postOffice);
		int errorCode = studentDAO.insertStudent(newStudent);
		
		if (errorCode == 1) {
			System.out.println("Cannot add the Student. " + "The student ID (" + studentID + ") is already in use.");
		} else if (errorCode == 0) {
			System.out.println("Student added!");
		} 
		
		
		input.close();
	}

}
