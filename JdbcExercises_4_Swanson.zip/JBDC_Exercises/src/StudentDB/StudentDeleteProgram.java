package StudentDB;

import java.util.Scanner;

import data_access.StudentDAO;

public class StudentDeleteProgram {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		StudentDAO studentDAO = new StudentDAO();

		int studentID = 0;
		boolean bool = false;

		while (bool != true) {
			try {
				System.out.println("=== Delete student ===");
				System.out.print("Enter the ID number of the student to be deleted: ");
				studentID = Integer.parseInt(input.nextLine());
				bool = true;
			} catch (NumberFormatException nfe) {
				System.out.println("The value input is not a number! Please enter another ID number.");
			}
		}

		studentDAO.deleteStudent(studentID);
		
		
		input.close();

	}

}
