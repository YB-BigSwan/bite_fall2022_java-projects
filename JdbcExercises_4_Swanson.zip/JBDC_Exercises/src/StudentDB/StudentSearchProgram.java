package StudentDB;

import java.util.List;
import java.util.Scanner;

import data_access.StudentDAO;
import model.Student;

public class StudentSearchProgram {

	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		StudentDAO studentDAO = new StudentDAO();
		

		int studentID = 0;
		boolean bool = false;
		System.out.println("=== Find student by id (DAO version) ===");
		while (bool != true) {
			try {
				System.out.print("Enter student id: ");
				studentID = Integer.parseInt(input.nextLine());
				
				bool = true;
			} catch (Exception e) {
				System.out.println("Invalid ID format! Please enter a valid student number.");
			}
		}
		
		List<Student> studentList = studentDAO.getStudentByID(studentID);
		
		if (studentList.isEmpty()) {
			System.out.println("Unknown student id (" + studentID + ")");
		} else {
			for (Student student : studentList) {
				System.out.println(student.getId() + ", " + student.getFirstName() + " " + student.getLastName() + ", " + student.getStreetAddress() + ", " + student.getPostcode() + " " + student.getPostOffice());
			}
		}
		
		input.close();

	}

}
