package servlet_exercises;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import model.Student;

/**
 * Servlet implementation class JsonServlet
 */
@WebServlet("/jsontest")
public class JsonServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public JsonServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Gson gson = new Gson();
		Student student1 = new Student(10, "hulk", "hogan", "123 cherry way", "01234", "A city");
		Student student2 = new Student(20, "muscle man randy", "savage", "456 cherry way", "01234", "The same city");
		List<Student> studentList = new ArrayList<Student>();
		
		studentList.add(student2);
		studentList.add(student1);
		
		String jsonString = gson.toJson(studentList);
		
		PrintWriter output = response.getWriter();
		output.print(jsonString);
		
	}

}
