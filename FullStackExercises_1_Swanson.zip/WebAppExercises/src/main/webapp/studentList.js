function main() {
	fetch('http://localhost:8080/WebAppExercises/students')
		.then(response => response.json())
		.then(studentList => printStudents(studentList));
}

function printStudents(studentList) {

	let tableRows;
	let studentTable = document.getElementById("tableOutput");
	
	for (i = 0; i < studentList.length; i++) {
		tableRows =
			`<tr>
				<td>${studentList[i].id}</td>
				<td>${studentList[i].firstName}</td>
				<td>${studentList[i].lastName}</td>
				<td>${studentList[i].streetAddress}</td>
				<td>${studentList[i].postcode}</td>
				<td>${studentList[i].postOffice}</td>
			</tr>`;
		studentTable.innerHTML += tableRows;
	}


}

main();